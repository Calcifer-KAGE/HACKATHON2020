package com.br.mopac;

import java.util.Objects;

/**
 * Created by Professor on 28/03/2017.
 */

public class Usuario implements Cloneable{
    private int id;
    private String login;
    private String password;

    public Usuario(){}

    public Usuario(String login,String password){
        this.login = login;
        this.password = password;
    }

    public Usuario(int id, String login,String password){
        this.id = id;
        this.login = login;
        this.password = password;
    }

    public Usuario(Usuario u){
        this.id = u.id;
        this.login = u.login;
        this.password = u.password;
    }

    public int getId(){
        return this.id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getLogin(){
        return this.login;
    }

    public void setLogin(String l){
        this.login = l;
    }

    public String getPassword(){
        return this.password;
    }
    public void setPassword(String p){
        this.password = p;
    }

    @Override
    public Object clone(){

        Usuario clone = new Usuario(this);

        return clone;

    }

}
