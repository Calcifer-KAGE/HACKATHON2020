package com.br.mopac;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Conversa extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversa);

    }

        public void CONTAGIO(View view){
            Intent intent = new Intent(this,Contato.class);
            startActivity(intent);
        }

        public void COLETA(View view){
            Intent intent = new Intent(this,Coleta.class);
            startActivity(intent);
        }

        public void CUIDADO(View view){
            Intent intent = new Intent(this,Cuidado.class);
            startActivity(intent);
        }

        public void CONTATO(View view){
            Intent intent = new Intent(this,Conversa.class);
            startActivity(intent);
        }

    }
