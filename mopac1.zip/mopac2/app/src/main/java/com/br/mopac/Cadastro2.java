package com.br.mopac;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Cadastro2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_endereco);
    }

    public void bntC2(View view){

        Intent intent = new Intent(this,Cadastro3.class);
        startActivity(intent);
    }

    public void bntCancelar(View view){

        Intent intent = new Intent(this,Login.class);
        startActivity(intent);
    }


}
