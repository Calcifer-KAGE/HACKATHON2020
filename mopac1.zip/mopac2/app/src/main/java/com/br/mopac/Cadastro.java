package com.br.mopac;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Cadastro extends AppCompatActivity {

        EditText edtCPF, edtSENHA;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_dados);

        edtCPF = (EditText) findViewById(R.id.TextCPFS);
        edtSENHA = (EditText) findViewById(R.id.textSENHAS);
    }



    public void bntC1(View view){

        BancoSQLite db = new BancoSQLite(this);

        if(db.inserirUsuario(new Usuario(
                edtCPF.getText().toString(),
                edtSENHA.getText().toString()))
        ){
            Toast.makeText(this, "Cadastro efetuado com sucesso!", Toast.LENGTH_SHORT).show();
        }

        else
            Toast.makeText(getBaseContext(), "Falha no Cadastro!", Toast.LENGTH_LONG).show();




        Intent intent = new Intent(this,Cadastro2.class);
        startActivity(intent);

    }


    public void bntCancelar(View view){

        Intent intent = new Intent(this,Login.class);
        startActivity(intent);
    }




}
