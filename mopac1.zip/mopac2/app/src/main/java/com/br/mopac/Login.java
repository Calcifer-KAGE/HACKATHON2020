package com.br.mopac;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

     EditText edtCPF, edtSENHA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        edtCPF = (EditText) findViewById(R.id.textCPF);
        edtSENHA = (EditText) findViewById(R.id.textSENHA);
    }


    public void criar(View view){

        Intent intent = new Intent(this,Cadastro.class);
        startActivity(intent);

    }
    public void login(View view){

    BancoSQLite db = new BancoSQLite(this);
    try{
            Usuario user = db.selecionarUsuario(edtCPF.getText().toString());

            if(user.getPassword().equals(edtSENHA.getText().toString())){
                Intent intent = new Intent(this,Home.class);
                startActivity(intent);
            }

            else
                Toast.makeText(this, "Usuario não cadastrado", Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(this, "Usuario não cadastrado", Toast.LENGTH_SHORT).show();
        }
        }
}