package com.br.mopac;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BancoSQLite extends SQLiteOpenHelper {

    private static final String NOME_BANCO = "MOPAC.db";

    private static final String ID = "id";

    private static final String LOGIN = "login";
    private static final String SENHA = "senha";

    private static final String NOME = "nome";
    private static final String NASCIMENTO = "nascimento";
    private static final String TELEFONE = "telefone";

    private static final String CEP = "cep";
    private static final String NUMERO = "numero";
    private static final String QUANTPESSOA = "quantpessoa";
    private static final String SANEAMENTOAGUA = "saneamentoagua";
    private static final String SANEAMENTOESGOTO = "saneamentoesgoto";
    private static final String INTERNETMOVEL = "internetmovel";
    private static final String INTERNETWIFI = "internetwifi";

    private static final String DIAGNOSTICOCOVID = "diagnosticocovid";
    private static final String CONTATOCOVID = "contatocovid";
    private static final String VACINAGRIPE = "vacinagripe";
    private static final String FUMANTE = "fumante";
    private static final String COMORBIDADE = "comorbidade";
    private static final String MEDICACAO = "medicacao";

    private static final String TABELA = "usuarios";
    private static final int VERSAO = 1;

    public BancoSQLite(Context context){

        super(context, NOME_BANCO,null,VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_USUARIOS_TABLE = "CREATE TABLE " + TABELA + " ( " +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NOME + " TEXT," +
                NASCIMENTO + " TEXT," +
                TELEFONE + " TEXT," +
                CEP + " TEXT," +
                NUMERO + " TEXT," +
                QUANTPESSOA + " TEXT," +
                SANEAMENTOAGUA + " TEXT," +
                SANEAMENTOESGOTO + " TEXT," +
                INTERNETMOVEL + " TEXT," +
                INTERNETWIFI + " TEXT," +
                DIAGNOSTICOCOVID + " TEXT," +
                CONTATOCOVID + " TEXT," +
                VACINAGRIPE + " TEXT," +
                FUMANTE + " TEXT," +
                COMORBIDADE + " TEXT," +
                MEDICACAO + " TEXT," +
                LOGIN + " TEXT," +
                SENHA + " TEXT )";

        db.execSQL(CREATE_USUARIOS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABELA);

        onCreate(db);
    }

    public boolean inserirUsuario(Usuario u){
        long result;

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values =  new ContentValues();
        values.put(LOGIN,u.getLogin());
        values.put(SENHA,u.getPassword());

        /*values.put(NOME, u.getNome());
        values.put(NASCIMENTO,u.getNascimento());
        values.put(TELEFONE,u.getTelefone());
        values.put(CEP,u.getCep());
        values.put(NUMERO,u.getNumero());
        values.put(QUANTPESSOA,u.getQUANTPESSOA());
        values.put(SANEAMENTOAGUA,u.getSaneamentoAgua());
        values.put(SANEAMENTOESGOTO,u.getSaneamentoEsgoto());
        values.put(INTERNETMOVEL,u.getInternetMovel());
        values.put(INTERNETWIFI,u.getInternetWifi());
        values.put(DIAGNOSTICOCOVID,u.getDiagnosticoCovid());
        values.put(CONTATOCOVID,u.getContatoCovid());
        values.put(VACINAGRIPE,u.getVacinaGripe());
        values.put(FUMANTE,u.getFumante());
        values.put(COMORBIDADE,u.getComorbidade());
        values.put(MEDICACAO,u.getMedicacao());

         */

        result = db.insert(TABELA,null,values);
        db.close();

        if(result == -1)
            return false;
        else
            return true;
    }

    public Usuario selecionarUsuario(String login){
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABELA,
                new String[]{ID,LOGIN,SENHA},
                LOGIN + " = ?",
                new String[]{ String.valueOf(login) },null,null,null, null);

        if(cursor != null) {
            cursor.moveToFirst();

            Usuario user = new Usuario(
                    Integer.parseInt(cursor.getString(0)),
                    cursor.getString(1),
                    cursor.getString(2));

            return (Usuario) user.clone();
        }else
            return null;
    }
}
